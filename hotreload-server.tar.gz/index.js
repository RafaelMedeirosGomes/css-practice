const fs = require("node:fs");
const WebSocket = require("./vendor/ws/lib/websocket-server");

const server = new WebSocket({ port: 5555 }, () => {
    console.debug("WS server online");
});

server.on("connection", function (socket) {
    console.debug(`Client connected`);

    fs.watch("/opt/html", function (_event, _filename) {
        socket.send(JSON.stringify({ branch: "changed" }));
        console.debug(`git branch changed event sent to client`);
    });
});